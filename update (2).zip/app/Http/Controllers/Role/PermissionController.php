<?php

namespace App\Http\Controllers\Role;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\info_user;

class PermissionController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:permission-index|permission-create|permission-edit|permission-delete', ['only' => ['index', 'show']]);
        $this->middleware('permission:permission-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:permission-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:permission-delete', ['only' => ['destroy']]);
    }
    public function index()
    {
        $permissions = Permission::with('roles:name')->get();
                $fotoId = auth()->user()->id;
        $userfoto = info_user::where('id_user', $fotoId)->first();

        return view('permission.index', compact('permissions','userfoto'));
    }

    public function create()
    {
        $roles = Role::pluck('name', 'id');
        $role = Role::all();
        $fotoId = auth()->user()->id;
        $userfoto = info_user::where('id_user', $fotoId)->first();
        return view('permission.create', compact('roles','userfoto', 'role'));
    }

    // public function store(Request $request) {
    //     $data = $request->validate([
    //         'name' => ['required', 'string', 'unique:permissions'],
    //         'roles' => ['array'],
    //     ]);

    //     $permission = Permission::create($data);

    //     $permission->syncRoles($request->input('roles'));

    //     return redirect()->route('permission.index')->with('success', 'Permission telah berhasil dibuat.');;
    // }
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'unique:permissions'],
            'roles' => ['array'],
        ]);

        $permission = Permission::create($data);

        if (in_array('select-all', $request->input('roles'))) {
            $roles = Role::pluck('id')->all();
        } else {
            $roles = $request->input('roles', []);
        }

        $permission->syncRoles($roles);

        return redirect()->route('permission.index')->with('success', 'Permission telah berhasil dibuat.');
    }


    public function edit(Permission $permission)
    {
        $roles = Role::pluck('name', 'id');
        $role = Role::all();
        return view('permission.edit', compact('permission', 'roles', 'role'));
    }

    public function update(Request $request, Permission $permission)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'unique:permissions,id,' . $permission->id],
            'roles' => ['array'],
        ]);

        $permission->update($data);

        if (in_array('select-all', $request->input('roles'))) {
            $roles = Role::pluck('id')->all();
        } else {
            $roles = $request->input('roles', []);
        }

        $permission->syncRoles($roles);

        return redirect()->route('permission.index')->with('success', 'Permission telah berhasil diperbarui.');
    }


    public function destroy(Permission $permission)
    {
        $permission->delete();

        return redirect()->route('permission.index')->with('success', 'Permission telah berhasil dihapus.');;
    }
}
